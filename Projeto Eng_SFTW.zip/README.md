# MedScheduler — Sistema de Agendamento de Consultas Médicas

**Stack**: FastAPI (Python) + SQLite + Jinja2 (templates)  
**Escopo**: Cadastro de médicos e pacientes; marcação, cancelamento e exclusão de consultas.  
**Entrega**: Aplicação Web leve, executável localmente.

## Como executar

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Abra http://127.0.0.1:8000 no navegador.

## Rotas principais (UI)
- `/` — Início
- `/doctors` — Lista e cadastro de médicos
- `/patients` — Lista e cadastro de pacientes
- `/appointments` — Listagem, agendamento, cancelamento e exclusão de consultas

## API (OpenAPI)
A documentação automática está disponível em `/docs` e `/redoc`.

## Regras de negócio
- Uma consulta tem `doctor_id`, `patient_id`, `appointment_time` e `status` (`scheduled` ou `canceled`).
- Impedimos sobreposição: o mesmo médico não pode ter duas consultas no **mesmo intervalo de 30 minutos**.
- Cancelar altera o `status` para `canceled`. Excluir remove definitivamente.

## Modelagem (ER)
```mermaid
erDiagram
  DOCTORS ||--o{ APPOINTMENTS : has
  PATIENTS ||--o{ APPOINTMENTS : has
  DOCTORS {int id PK, string name, string specialty, datetime created_at}
  PATIENTS {int id PK, string name, string email, datetime created_at}
  APPOINTMENTS {int id PK, int doctor_id FK, int patient_id FK, datetime appointment_time, enum status, datetime created_at}
```

## Estrutura de diretórios
```
app/
  crud.py
  database.py
  main.py
  models.py
  schemas.py
  templates/
    base.html
    index.html
    doctors.html
    patients.html
    appointments.html
  static/
    styles.css
requirements.txt
README.md
diagrams/er.drawio
```

## Segurança e próximos passos
- Adicionar autenticação (Keycloak/OAuth2) e autorização por perfil.
- Validações mais fortes (e.g., e-mail único opcional, telefone, CRM do médico).
- Testes automatizados (pytest) e CI.
- Dockerfile e Compose para subir rapidamente.
- Migrações com Alembic.
- Deploy no Fly.io/Render.
```