from fastapi import FastAPI, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from datetime import datetime
from .database import SessionLocal, engine, Base
from . import models, schemas, crud

Base.metadata.create_all(bind=engine)

app = FastAPI(title="MedScheduler - Sistema de Agendamento Médico")

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# Doctors
@app.get("/doctors", response_class=HTMLResponse)
def doctors_page(request: Request, db: Session = Depends(get_db)):
    doctors = crud.list_doctors(db)
    return templates.TemplateResponse("doctors.html", {"request": request, "doctors": doctors, "message": None, "error": None})

@app.post("/doctors/create")
def doctors_create(name: str = Form(...), specialty: str = Form(None), db: Session = Depends(get_db)):
    try:
        crud.create_doctor(db, schemas.DoctorCreate(name=name, specialty=specialty))
        return RedirectResponse(url="/doctors", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/doctors/{doctor_id}/delete")
def doctors_delete(doctor_id: int, db: Session = Depends(get_db)):
    ok = crud.delete_doctor(db, doctor_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Médico não encontrado")
    return RedirectResponse(url="/doctors", status_code=303)

# Patients
@app.get("/patients", response_class=HTMLResponse)
def patients_page(request: Request, db: Session = Depends(get_db)):
    patients = crud.list_patients(db)
    return templates.TemplateResponse("patients.html", {"request": request, "patients": patients, "message": None, "error": None})

@app.post("/patients/create")
def patients_create(name: str = Form(...), email: str | None = Form(None), db: Session = Depends(get_db)):
    try:
        crud.create_patient(db, schemas.PatientCreate(name=name, email=email if email else None))
        return RedirectResponse(url="/patients", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/patients/{patient_id}/delete")
def patients_delete(patient_id: int, db: Session = Depends(get_db)):
    ok = crud.delete_patient(db, patient_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Paciente não encontrado")
    return RedirectResponse(url="/patients", status_code=303)

# Appointments
@app.get("/appointments", response_class=HTMLResponse)
def appointments_page(request: Request, db: Session = Depends(get_db)):
    appts = crud.list_appointments(db)
    doctors = crud.list_doctors(db)
    patients = crud.list_patients(db)
    return templates.TemplateResponse("appointments.html", {
        "request": request, "appointments": appts, "doctors": doctors, "patients": patients
    })

@app.post("/appointments/create")
def appointments_create(
    doctor_id: int = Form(...),
    patient_id: int = Form(...),
    appointment_time: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        dt = datetime.fromisoformat(appointment_time)
    except Exception:
        raise HTTPException(status_code=400, detail="Formato de data/hora inválido. Use YYYY-MM-DDTHH:MM")
    try:
        crud.create_appointment(db, schemas.AppointmentCreate(
            doctor_id=doctor_id, patient_id=patient_id, appointment_time=dt
        ))
        return RedirectResponse(url="/appointments", status_code=303)
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))

@app.post("/appointments/{appt_id}/cancel")
def appointments_cancel(appt_id: int, db: Session = Depends(get_db)):
    ok = crud.cancel_appointment(db, appt_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Consulta não encontrada ou já cancelada")
    return RedirectResponse(url="/appointments", status_code=303)

@app.post("/appointments/{appt_id}/delete")
def appointments_delete(appt_id: int, db: Session = Depends(get_db)):
    ok = crud.delete_appointment(db, appt_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Consulta não encontrada")
    return RedirectResponse(url="/appointments", status_code=303)