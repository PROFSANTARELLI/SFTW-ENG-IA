from sqlalchemy.orm import Session
from sqlalchemy import select, and_
from datetime import datetime, timedelta
from . import models, schemas

# Doctors
def create_doctor(db: Session, data: schemas.DoctorCreate):
    doctor = models.Doctor(name=data.name, specialty=data.specialty)
    db.add(doctor)
    db.commit()
    db.refresh(doctor)
    return doctor

def list_doctors(db: Session):
    return db.execute(select(models.Doctor).order_by(models.Doctor.name)).scalars().all()

def delete_doctor(db: Session, doctor_id: int):
    doctor = db.get(models.Doctor, doctor_id)
    if doctor:
        db.delete(doctor)
        db.commit()
        return True
    return False

# Patients
def create_patient(db: Session, data: schemas.PatientCreate):
    patient = models.Patient(name=data.name, email=data.email)
    db.add(patient)
    db.commit()
    db.refresh(patient)
    return patient

def list_patients(db: Session):
    return db.execute(select(models.Patient).order_by(models.Patient.name)).scalars().all()

def delete_patient(db: Session, patient_id: int):
    patient = db.get(models.Patient, patient_id)
    if patient:
        db.delete(patient)
        db.commit()
        return True
    return False

# Appointments
def create_appointment(db: Session, data: schemas.AppointmentCreate):
    # simplistic overlap rule: same doctor cannot have two appointments within the same 30-minute window
    window_start = data.appointment_time - timedelta(minutes=29, seconds=59)
    window_end = data.appointment_time + timedelta(minutes=29, seconds=59)
    conflict = db.execute(
        select(models.Appointment).where(
            and_(
                models.Appointment.doctor_id == data.doctor_id,
                models.Appointment.status == models.AppointmentStatus.scheduled,
                models.Appointment.appointment_time.between(window_start, window_end),
            )
        )
    ).first()
    if conflict:
        raise ValueError("Conflito: o médico já possui consulta nesse intervalo de 30 minutos.")
    appt = models.Appointment(
        doctor_id=data.doctor_id,
        patient_id=data.patient_id,
        appointment_time=data.appointment_time,
        status=models.AppointmentStatus.scheduled,
    )
    db.add(appt)
    db.commit()
    db.refresh(appt)
    return appt

def list_appointments(db: Session):
    return db.execute(
        select(models.Appointment).order_by(models.Appointment.appointment_time.desc())
    ).scalars().all()

def cancel_appointment(db: Session, appt_id: int):
    appt = db.get(models.Appointment, appt_id)
    if appt and appt.status != models.AppointmentStatus.canceled:
        appt.status = models.AppointmentStatus.canceled
        db.commit()
        db.refresh(appt)
        return True
    return False

def delete_appointment(db: Session, appt_id: int):
    appt = db.get(models.Appointment, appt_id)
    if appt:
        db.delete(appt)
        db.commit()
        return True
    return False