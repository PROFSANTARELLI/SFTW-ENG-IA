from pydantic import BaseModel, EmailStr, field_validator
from datetime import datetime

class DoctorCreate(BaseModel):
    name: str
    specialty: str | None = None

class PatientCreate(BaseModel):
    name: str
    email: EmailStr | None = None

class AppointmentCreate(BaseModel):
    doctor_id: int
    patient_id: int
    appointment_time: datetime

    @field_validator('appointment_time')
    def not_past(cls, v: datetime):
        if v < datetime.now():
            raise ValueError("Horário da consulta não pode estar no passado.")
        return v